p1 = input("Introdueix la primera paraula: ") # Demanem la primera paraula a l'usuari
p2 = input("Introdueix la segona paraula: ") # Demanem la segona paraula a l'usuari
p3 = input("Introdueix la tercera paraula: ") # Demanem la tercera paraula a l'usuari

print("La frase és: " + p1 + " " + p2 + " " + p3) # Imprimim la frase completa a la consola