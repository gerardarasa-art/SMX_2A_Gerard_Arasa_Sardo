a = float(input("Introdueix el primer valor: ")) # Convertim l'entrada a float per permetre nombres decimals
b = float(input("Introdueix el segon valor: ")) # Convertim l'entrada a float per permetre nombres decimals

print("La suma és: ", a + b) # Imprimim el resultat de la suma
print("La resta és: ", a - b) # Imprimim el resultat de la resta
print("La multiplicació és: ", a * b) # Imprimim el resultat de la multiplicació
print("La divisió és: ", a / b) # Imprimim el resultat de la divisió