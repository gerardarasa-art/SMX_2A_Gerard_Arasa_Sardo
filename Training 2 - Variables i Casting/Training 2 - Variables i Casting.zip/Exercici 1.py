Costat = float(input("Introdueix el costat del quadrat: ")) # Demanem el costat del quadrat a l'usuari

Area = Costat * Costat # Calculem l'àrea del quadrat

print("L'àrea del quadrat és: ", Area) # Imprimim el resultat a la consola