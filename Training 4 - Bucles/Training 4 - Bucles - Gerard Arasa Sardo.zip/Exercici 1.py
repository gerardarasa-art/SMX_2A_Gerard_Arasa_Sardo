print("Nombres parells entre 1 i 200:") # Imprimeix el missatge d'inici

X = 2 # Primer nombre parell

while X <= 200: # Bucle mentre X sigui menor o igual a 200
    print(X)
    X += 2
# Incrementa X en 2 per obtenir el següent nombre parell