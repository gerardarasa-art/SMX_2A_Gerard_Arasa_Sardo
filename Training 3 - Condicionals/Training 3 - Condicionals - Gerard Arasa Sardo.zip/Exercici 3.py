# Demana un nombre a l'usuari
nombre = int(input("Introdueix un nombre enter: "))

# Comprova si el nombre és zero o més (Positiu)
if nombre >= 0:
    print("El nombre és positiu (o zero)")
else:
    print("El nombre és negatiu")