# Demana l'edat a l'usuari i la converteix a un nombre enter
edat = int(input("Introdueix la teva edat: "))

# Comprova si l'edat és 18 o més
if edat >= 18:
    print("Ets major d'edat")
else:
    print("Ets menor d'edat")